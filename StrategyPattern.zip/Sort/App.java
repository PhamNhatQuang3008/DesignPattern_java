package Sort;

import Sort.BubbleSort;
import Sort.InsertionSort;
import Sort.SelectionSort;
import Sort.SortContext;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SortContext context = new SortContext();

        System.out.println("Enter the size of the array:");
        int size = scanner.nextInt();
        int[] array = new int[size];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.println("Choose sorting algorithm:");
        System.out.println("1 - Bubble Sort");
        System.out.println("2 - Selection Sort");
        System.out.println("3 - Insertion Sort");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                context.setStrategy(new BubbleSort());
                break;
            case 2:
                context.setStrategy(new SelectionSort());
                break;
            case 3:
                context.setStrategy(new InsertionSort());
                break;
            default:
                System.out.println("Invalid choice!");
                return;
        }

        // Sorting the array using the chosen strategy
        context.sortArray(array);

        // Display sorted array
        System.out.println("Sorted Array:");
        for (int num : array) {
            System.out.print(num + " ");
        }
    }
}
