package Sort;

// SortContext.java
public class SortContext {
    private SortStrategy strategy;

    // Set the sorting strategy at runtime
    public void setStrategy(SortStrategy strategy) {
        this.strategy = strategy;
    }

    // Sort the array using the selected strategy
    public void sortArray(int[] array) {
        if (strategy != null) {
            strategy.sort(array);
        } else {
            System.out.println("No sorting strategy selected.");
        }
    }
}
