package PseudoCode;

// Context.java
public class Context {
    private Strategy strategy;

    // Set the strategy dynamically
    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    // Execute the current strategy
    public int executeStrategy(int a, int b) {
        if (strategy != null) {
            return strategy.execute(a ,b);
        }
        throw new IllegalStateException("Strategy not set.");
    }
}
