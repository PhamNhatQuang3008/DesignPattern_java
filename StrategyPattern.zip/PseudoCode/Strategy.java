package PseudoCode;

// Strategy.java
public interface Strategy {
    int execute(int a, int b);
}
