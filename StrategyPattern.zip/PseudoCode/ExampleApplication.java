package PseudoCode;

import java.util.Scanner;

public class ExampleApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Context context = new Context();

        // Read first and second numbers
        System.out.print("Enter the first number: ");
        int firstNumber = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int secondNumber = scanner.nextInt();

        // Read the desired action from user input
        System.out.println("Choose an operation: addition, subtraction, multiplication");
        String action = scanner.next().toLowerCase();

        // Set strategy based on user choice
        switch (action) {
            case "addition":
                context.setStrategy(new ConcreteStrategyAdd());
                break;
            case "subtraction":
                context.setStrategy(new ConcreteStrategySubtract());
                break;
            case "multiplication":
                context.setStrategy(new ConcreteStrategySubtract());
                break;
            default:
                System.out.println("Invalid operation choice!");
                return;
        }

        // Execute the strategy and display the result
        int result = context.executeStrategy(firstNumber, secondNumber);
        System.out.println("Result: " + result);
    }
}
