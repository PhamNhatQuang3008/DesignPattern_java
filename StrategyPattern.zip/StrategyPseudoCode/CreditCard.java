package StrategyPseudoCode;

public class CreditCard {
    private int amount;
    private String number;
    private String date;
    private String cardVerificationValue;

    // Constructor
    public CreditCard(String number, String date, String cardVerificationValue) {
        this.amount = 100000; // Default initial balance
        this.number = number;
        this.date = date;
        this.cardVerificationValue = cardVerificationValue;
    }

    // Setter for amount
    public void setAmount(int amount) {
        this.amount = amount;
    }

    // Getter for amount
    public int getAmount() {
        return amount;
    }

    // Getter for card number
    public String getNumber() {
        return this.number;
    }

    @Override
    public String toString() {
        return "CreditCard{" +
                "number='" + number + '\'' +
                ", expirationDate='" + date + '\'' +
                ", amount=" + amount +
                '}';
    }
}
