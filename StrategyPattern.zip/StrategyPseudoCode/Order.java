package StrategyPseudoCode;

import StrategyPseudoCode.PayStrategy;


/**
 * Order class. Uses Singleton pattern.
 */
public class Order {
    private static final Order INSTANCE = new Order();
    private int totalCost = 0;
    private boolean isClosed = false;

    // Private constructor for Singleton
    private Order() {}

    // Get the Singleton instance
    public static Order getInstance() {
        return INSTANCE;
    }

    public void processOrder(PayStrategy strategy) {
        strategy.collectPaymentDetails();
        if (strategy.pay(totalCost)) {
            System.out.println("Payment has been successful.");
            setClosed();
        }
    }

    public void setTotalCost(int cost) {
        this.totalCost += cost;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public boolean isClosed() {
        return isClosed;
    }

    private void setClosed() {
        isClosed = true;
    }
}
