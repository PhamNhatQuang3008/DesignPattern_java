public class Engine {
    String type;

    public Engine(String type) {
        this.type = type;
    }
}