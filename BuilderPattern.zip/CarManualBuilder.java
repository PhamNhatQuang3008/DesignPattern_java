// src/CarManualBuilder.java
public class CarManualBuilder implements Builder {
    protected Manual manual;

    @Override
    public void reset() {
        this.manual = new Manual();
    }

    @Override
    public void setSeats(int numbers) {
        manual.seats = numbers;
    }

    @Override
    public void setEngine(Engine engine) {
        manual.engine = engine;
    }

    @Override
    public void setTripComputer() {
        manual.TripComputer = "Standard Trip Computer";
    }

    @Override
    public void setGPS() {
        manual.GPS = "Standard GPS";
    }

    public Manual getResult() {
        return manual;
    }
}