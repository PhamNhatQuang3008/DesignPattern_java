public class Director {
    public void makeSUV(Builder builder){

    }
    public void makeSportCar(Builder builder){

    }
}