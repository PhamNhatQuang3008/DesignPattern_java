package Ex1;

public class DecoratorPatternDemo {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle();
        Shape redRectangle = new RedShapeDecorator(rectangle);

        System.out.println("Rectangle with normal border");
        rectangle.draw();

        System.out.println("\nRectangle with red border");
        redRectangle.draw();
    }
}