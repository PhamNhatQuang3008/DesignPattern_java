package Ex1;

public class Rectangle implements Shape{
    public void draw() {

    }
}
