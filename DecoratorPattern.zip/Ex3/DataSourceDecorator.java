package Ex3;

public class DataSourceDecorator implements DataSource {
        protected DataSource wrappee;
        public DataSourceDecorator(DataSource wrappe) {
            this.wrappee = wrappee;
        }

    @Override
    public void writeData(DataSource data) {
        wrappee.writeData(data);
    }

    @Override
    public DataSource readData() {
        return wrappee.readData();
    }
}
