package Ex2;
public interface IceCream {
    String getDescription();
}