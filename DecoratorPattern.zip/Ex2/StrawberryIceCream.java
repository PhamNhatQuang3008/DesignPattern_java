package Ex2;

public class StrawberryIceCream implements IceCream {
    @Override
    public String getDescription() {
        return null;
    }
}
