public class FictionBook extends Book {
    private String genre;

    public FictionBook(String title, String author, int pages, String genre) {
        super(title, author, pages);
        this.genre = genre;
    }

    @Override
    public String toString() {
        return "FictionBook{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", pages=" + pages +
                ", genre='" + genre + '\'' +
                '}';
    }

    @Override
    public double calculatePrice() {
        return pages * 1000;
    }
}