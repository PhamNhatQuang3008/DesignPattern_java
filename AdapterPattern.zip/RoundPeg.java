public class RoundPeg {
    public int radius;
    public RoundPeg(int radius) {
        this.radius = radius;
    }
   public int getRadius() {
        return radius;
   }

}
