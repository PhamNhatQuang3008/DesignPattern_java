public class TechnicalBook extends Book {
    private String subject;

    public TechnicalBook(String title, String author, int pages, String subject) {
        super(title, author, pages);
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "TechnicalBook{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", pages=" + pages +
                ", subject='" + subject + '\'' +
                '}';
    }

    @Override
    public double calculatePrice() {
        double price = pages * 1000;
        if (price > 150000) {
            price -= price * 0.05;
        } else if (price > 100000) {
            price -= price * 0.03;
        } else {
            price -= price * 0.01;
        }
        return price;
    }
}