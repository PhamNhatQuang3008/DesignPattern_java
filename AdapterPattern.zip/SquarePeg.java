public class SquarePeg {
    public int width;
    public SquarePeg(int width) {
        this.width = width;
    }
    public int getWidth() {
       return width;
    }
    public double getRadius() {
        return width * Math.sqrt(2) /2 ;
     }

}
