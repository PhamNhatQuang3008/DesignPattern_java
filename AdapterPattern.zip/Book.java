public abstract class Book {
    protected String title;
    protected String author;
    protected int pages;

    public Book(String title, String author, int pages) {
       this.title = title;
        this.author = author;
        this.pages = pages;

    }

    public abstract String toString();
    public abstract double calculatePrice();
}