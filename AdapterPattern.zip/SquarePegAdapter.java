public class SquarePegAdapter extends RoundPeg {
    public SquarePeg peg;
    public SquarePegAdapter(SquarePeg peg ) {
        super((int) peg.getWidth());
        this.peg = peg;

    }
    public int getRadius() {
     return (int) peg.getRadius();
    }
}
