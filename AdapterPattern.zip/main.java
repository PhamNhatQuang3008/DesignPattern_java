public class main {
    public static void main(String[] args) {
        FictionBook fictionBook = new FictionBook("Harry Potter",
                "J.K. Rowling", 500, "Fantasy");
        System.out.println(fictionBook.toString());
        System.out.println("Price: " + fictionBook.calculatePrice());

        TechnicalBook technicalBook = new TechnicalBook("Introduction to Algorithms",
                "Thomas H. Cormen", 1312, "Computer Science");
        System.out.println(technicalBook.toString());
        System.out.println("Price: " + technicalBook.calculatePrice());
    }
}