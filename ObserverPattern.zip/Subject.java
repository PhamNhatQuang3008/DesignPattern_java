import java.util.*;

public class Subject {


  List<Observer> observers = new ArrayList<Observer>();
    public int state;
    public int getState() {
        return state;
    }
    public void setState(int state ) {
        this.state = state;
        notifyAllObservers();

    }
    public void attach(Observer observer) {
      observers.add(observer);

    }
    public void notifyAllObservers() {
      for(Observer ob : observers) {
        ob.update();
      }
      // Dùng hàm for để chạy Notify đến tất cả các Observer //

    }
}
