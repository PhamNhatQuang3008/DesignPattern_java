public class OctalObserver extends Observer{
    public Subject subject;
    public OctalObserver(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @java.lang.Override
    public void update() {
        System.out.println("Octal String: " + Integer.toOctalString(subject.getState()));




    }
}
