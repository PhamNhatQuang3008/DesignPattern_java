public class BinaryObserver extends Observer {
    public Subject subject;
    public BinaryObserver(Subject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }

    @java.lang.Override
    public void update() {
        System.out.println("Binary String : " + Integer.toBinaryString(subject.getState()));
        // Chuyển đổi state => số nhị phân //

    }
}
