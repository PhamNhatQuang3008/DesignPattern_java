public class ObserverPatternDemo {
    public static void main(String[] args) {
        Subject sub = new Subject();
        BinaryObserver bin = new BinaryObserver(sub);
        OctalObserver oct = new OctalObserver(sub);
        HexalObserver hex = new HexalObserver(sub);

        System.out.println("First state change: 15");
        sub.setState(15);
        System.out.println("------------------------");
        System.out.println("Second state change: 10");
        sub.setState(10);



    }

}
