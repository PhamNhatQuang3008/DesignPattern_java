public class Main {

    public static void main(String[] args) {
        SingletonExample firstInstance = SingletonExample.getInstance("Hello from the Singleton class!");
        System.out.println(firstInstance.getMessage());

        SingletonExample secondInstance = SingletonExample.getInstance("This message won't be shown");
        System.out.println(secondInstance.getMessage());

        if (firstInstance == secondInstance) {
            System.out.println("Both instances are the same");
        } else {
            System.out.println("Instances are different");
        }
    }
}
