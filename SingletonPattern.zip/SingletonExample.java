public class SingletonExample {
    private static SingletonExample instance;
    private String messenger;
    private SingletonExample(String messenger) {
        this.messenger = messenger;
    }
    public static SingletonExample getInstance(String messenger) {
        if(instance == null) {
            instance = new SingletonExample(messenger);
        }
        return instance;
    }

    public String getMessage() {
        return this.messenger;
    }
}
