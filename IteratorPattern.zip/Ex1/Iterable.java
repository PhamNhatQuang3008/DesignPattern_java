package Ex1;

import java.util.Iterator;

public interface Iterable {
    Iterator getIterator();
}
