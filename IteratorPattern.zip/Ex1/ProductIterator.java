package Ex1;

import java.util.Iterator;

public class ProductIterator implements Iterator {

    private String[] products;
    private int position = 0;

    public ProductIterator(String[] products) {
        this.products = products;
    }

    @Override
    public boolean hasNext() {
        return position < products.length;
    }

    @Override
    public Object next() {
        if (this.hasNext()) {
            return products[position++];
        }
        return null;
    }
}