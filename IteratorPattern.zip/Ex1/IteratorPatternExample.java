// Main class to demonstrate the Iterator Pattern
package Ex1;

import java.util.Iterator;

public class IteratorPatternExample {
    public static void main(String[] args) {
        String[] products = {"Product A", "Product B", "Product C", "Product D"};

        ProductCatalog catalog = new ProductCatalog(products);
        Iterator iterator = catalog.getIterator();

        System.out.println("Product List:");
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}