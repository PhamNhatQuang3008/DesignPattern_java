package Ex3_Example;

public interface MyIterable {
    MyIterator iterator();
}
