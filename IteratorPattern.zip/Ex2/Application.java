package Ex2;

public class Application {
    public static void main(String[] args) {
        Facebook facebook = new Facebook();
        Profile userProfile = new Profile("user1", "user1@example.com");

        ProfileIterator friendsIterator = facebook.createFriendsIterator(userProfile);
        SocialSpammer.send(friendsIterator, "Hello, friend!");

        ProfileIterator coworkersIterator = facebook.createCoworkersIterator(userProfile);
        SocialSpammer.send(coworkersIterator, "Hello, coworker!");
    }
}