package Ex2;

import Ex1.Iterator;

public interface SocialSpammer {
    public static void send(ProfileIterator iterator, String message) {
        while (iterator.hasMore()) {
            Profile profile = iterator.getNext();
            System.out.println("Sending message to " + profile.getEmail() + ": " + message);
        }
    }
}
