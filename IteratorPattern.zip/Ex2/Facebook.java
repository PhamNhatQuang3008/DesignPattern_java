package Ex2;

import java.util.ArrayList;
import java.util.List;

public class Facebook implements SocialNetwork {
    public List<Profile> requestProfiles(String profileId, String type) {
        // Simulate fetching profiles from a database or API
        List<Profile> profiles = new ArrayList<>();
        profiles.add(new Profile("1", "friend1@example.com"));
        profiles.add(new Profile("2", "friend2@example.com"));
        return profiles;
    }

    @Override
    public ProfileIterator createFriendsIterator(Profile profile) {
        return new FacebookIterator(this, profile.getId(), "friends");
    }

    @Override
    public ProfileIterator createCoworkersIterator(Profile profile) {
        return new FacebookIterator(this, profile.getId(), "coworkers");
    }
}