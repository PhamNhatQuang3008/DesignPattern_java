package Ex2;

public interface ProfileIterator {
    Profile getNext();
    boolean hasMore();
}
