package Ex2;

public interface SocialNetwork {
    ProfileIterator createFriendsIterator(Profile profile);
    ProfileIterator createCoworkersIterator(Profile profile);
}